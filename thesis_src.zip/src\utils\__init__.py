"""Utility functions"""
